package com.first;

import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
import org.springframework.stereotype.Controller;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

/**@RestController**/

@Controller
public class ControllerClass1 
{
	@RequestMapping("/courses")
  public String courses(HttpServletRequest req)
  {
		HttpSession session=req.getSession();
		
		String course=req.getParameter("course");
		
		session.setAttribute("yourCourse", course);
	  return "courses.jsp";
  }
}
